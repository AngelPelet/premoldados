function pisos(){
    let pisos = document.querySelector('#pisos')
    let revestimentos = document.querySelector('#revestimentos')
    let cobogos = document.querySelector('#cobogos')
    let blocos = document.querySelector('#blocos')
    let meiofio = document.querySelector('#meiofio')
    let pingadeira = document.querySelector('#pingadeira')

    pisos.style.display = 'block'
    revestimentos.style.display = 'none'
    cobogos.style.display = 'none'
    blocos.style.display = 'none'
    meiofio.style.display = 'none'
    pingadeira.style.display = 'none'

    let pisos1 = document.querySelector('.pisos')
    let revestimentos1 = document.querySelector('.revestimentos')
    let cobogos1 = document.querySelector('.cobogos')
    let blocos1 = document.querySelector('.blocos')
    let meiofio1 = document.querySelector('.meiofio')
    let pingadeira1 = document.querySelector('.pingadeira')

    pisos1.classList.add('ativo')
    revestimentos1.classList.remove('ativo')
    cobogos1.classList.remove('ativo')
    blocos1.classList.remove('ativo')
    meiofio1.classList.remove('ativo')
    pingadeira1.classList.remove('ativo')
}

function revestimentos(){
    let pisos = document.querySelector('#pisos')
    let revestimentos = document.querySelector('#revestimentos')
    let cobogos = document.querySelector('#cobogos')
    let blocos = document.querySelector('#blocos')
    let meiofio = document.querySelector('#meiofio')
    let pingadeira = document.querySelector('#pingadeira')

    pisos.style.display = 'none'
    revestimentos.style.display = 'block'
    cobogos.style.display = 'none'
    blocos.style.display = 'none'
    meiofio.style.display = 'none'
    pingadeira.style.display = 'none'

    let pisos1 = document.querySelector('.pisos')
    let revestimentos1 = document.querySelector('.revestimentos')
    let cobogos1 = document.querySelector('.cobogos')
    let blocos1 = document.querySelector('.blocos')
    let meiofio1 = document.querySelector('.meiofio')
    let pingadeira1 = document.querySelector('.pingadeira')

    pisos1.classList.remove('ativo')
    revestimentos1.classList.add('ativo')
    cobogos1.classList.remove('ativo')
    blocos1.classList.remove('ativo')
    meiofio1.classList.remove('ativo')
    pingadeira1.classList.remove('ativo')
}

function cobogos(){
    let pisos = document.querySelector('#pisos')
    let revestimentos = document.querySelector('#revestimentos')
    let cobogos = document.querySelector('#cobogos')
    let blocos = document.querySelector('#blocos')
    let meiofio = document.querySelector('#meiofio')
    let pingadeira = document.querySelector('#pingadeira')

    pisos.style.display = 'none'
    revestimentos.style.display = 'none'
    cobogos.style.display = 'block'
    blocos.style.display = 'none'
    meiofio.style.display = 'none'
    pingadeira.style.display = 'none'

    let pisos1 = document.querySelector('.pisos')
    let revestimentos1 = document.querySelector('.revestimentos')
    let cobogos1 = document.querySelector('.cobogos')
    let blocos1 = document.querySelector('.blocos')
    let meiofio1 = document.querySelector('.meiofio')
    let pingadeira1 = document.querySelector('.pingadeira')

    pisos1.classList.remove('ativo')
    revestimentos1.classList.remove('ativo')
    cobogos1.classList.add('ativo')
    blocos1.classList.remove('ativo')
    meiofio1.classList.remove('ativo')
    pingadeira1.classList.remove('ativo')
}

function blocos(){
    let pisos = document.querySelector('#pisos')
    let revestimentos = document.querySelector('#revestimentos')
    let cobogos = document.querySelector('#cobogos')
    let blocos = document.querySelector('#blocos')
    let meiofio = document.querySelector('#meiofio')
    let pingadeira = document.querySelector('#pingadeira')

    pisos.style.display = 'none'
    revestimentos.style.display = 'none'
    cobogos.style.display = 'none'
    blocos.style.display = 'block'
    meiofio.style.display = 'none'
    pingadeira.style.display = 'none'

    let pisos1 = document.querySelector('.pisos')
    let revestimentos1 = document.querySelector('.revestimentos')
    let cobogos1 = document.querySelector('.cobogos')
    let blocos1 = document.querySelector('.blocos')
    let meiofio1 = document.querySelector('.meiofio')
    let pingadeira1 = document.querySelector('.pingadeira')

    pisos1.classList.remove('ativo')
    revestimentos1.classList.remove('ativo')
    cobogos1.classList.remove('ativo')
    blocos1.classList.add('ativo')
    meiofio1.classList.remove('ativo')
    pingadeira1.classList.remove('ativo')
}

function meiofio(){
    let pisos = document.querySelector('#pisos')
    let revestimentos = document.querySelector('#revestimentos')
    let cobogos = document.querySelector('#cobogos')
    let blocos = document.querySelector('#blocos')
    let meiofio = document.querySelector('#meiofio')
    let pingadeira = document.querySelector('#pingadeira')

    pisos.style.display = 'none'
    revestimentos.style.display = 'none'
    cobogos.style.display = 'none'
    blocos.style.display = 'none'
    meiofio.style.display = 'block'
    pingadeira.style.display = 'none'

    let pisos1 = document.querySelector('.pisos')
    let revestimentos1 = document.querySelector('.revestimentos')
    let cobogos1 = document.querySelector('.cobogos')
    let blocos1 = document.querySelector('.blocos')
    let meiofio1 = document.querySelector('.meiofio')
    let pingadeira1 = document.querySelector('.pingadeira')

    pisos1.classList.remove('ativo')
    revestimentos1.classList.remove('ativo')
    cobogos1.classList.remove('ativo')
    blocos1.classList.remove('ativo')
    meiofio1.classList.add('ativo')
    pingadeira1.classList.remove('ativo')
}

function pingadeira(){
    let pisos = document.querySelector('#pisos')
    let revestimentos = document.querySelector('#revestimentos')
    let cobogos = document.querySelector('#cobogos')
    let blocos = document.querySelector('#blocos')
    let meiofio = document.querySelector('#meiofio')
    let pingadeira = document.querySelector('#pingadeira')

    pisos.style.display = 'none'
    revestimentos.style.display = 'none'
    cobogos.style.display = 'none'
    blocos.style.display = 'none'
    meiofio.style.display = 'none'
    pingadeira.style.display = 'block'

    let pisos1 = document.querySelector('.pisos')
    let revestimentos1 = document.querySelector('.revestimentos')
    let cobogos1 = document.querySelector('.cobogos')
    let blocos1 = document.querySelector('.blocos')
    let meiofio1 = document.querySelector('.meiofio')
    let pingadeira1 = document.querySelector('.pingadeira')

    pisos1.classList.remove('ativo')
    revestimentos1.classList.remove('ativo')
    cobogos1.classList.remove('ativo')
    blocos1.classList.remove('ativo')
    meiofio1.classList.remove('ativo')
    pingadeira1.classList.add('ativo')
}