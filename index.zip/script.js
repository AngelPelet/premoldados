function pisos(){
    let pisos = document.querySelector('#pisos')
    let revestimentos = document.querySelector('#revestimentos')
    let cobogos = document.querySelector('#cobogos')
    let blocos = document.querySelector('#blocos')
    let meiofio = document.querySelector('#meiofio')
    let pingadeira = document.querySelector('#pingadeira')

    pisos.style.display = 'block'
    revestimentos.style.display = 'none'
    cobogos.style.display = 'none'
    blocos.style.display = 'none'
    meiofio.style.display = 'none'
    pingadeira.style.display = 'none'
}

function revestimentos(){
    let pisos = document.querySelector('#pisos')
    let revestimentos = document.querySelector('#revestimentos')
    let cobogos = document.querySelector('#cobogos')
    let blocos = document.querySelector('#blocos')
    let meiofio = document.querySelector('#meiofio')
    let pingadeira = document.querySelector('#pingadeira')

    pisos.style.display = 'none'
    revestimentos.style.display = 'block'
    cobogos.style.display = 'none'
    blocos.style.display = 'none'
    meiofio.style.display = 'none'
    pingadeira.style.display = 'none'
}

function cobogos(){
    let pisos = document.querySelector('#pisos')
    let revestimentos = document.querySelector('#revestimentos')
    let cobogos = document.querySelector('#cobogos')
    let blocos = document.querySelector('#blocos')
    let meiofio = document.querySelector('#meiofio')
    let pingadeira = document.querySelector('#pingadeira')

    pisos.style.display = 'none'
    revestimentos.style.display = 'none'
    cobogos.style.display = 'block'
    blocos.style.display = 'none'
    meiofio.style.display = 'none'
    pingadeira.style.display = 'none'
}

function blocos(){
    let pisos = document.querySelector('#pisos')
    let revestimentos = document.querySelector('#revestimentos')
    let cobogos = document.querySelector('#cobogos')
    let blocos = document.querySelector('#blocos')
    let meiofio = document.querySelector('#meiofio')
    let pingadeira = document.querySelector('#pingadeira')

    pisos.style.display = 'none'
    revestimentos.style.display = 'none'
    cobogos.style.display = 'none'
    blocos.style.display = 'block'
    meiofio.style.display = 'none'
    pingadeira.style.display = 'none'
}

function meiofio(){
    let pisos = document.querySelector('#pisos')
    let revestimentos = document.querySelector('#revestimentos')
    let cobogos = document.querySelector('#cobogos')
    let blocos = document.querySelector('#blocos')
    let meiofio = document.querySelector('#meiofio')
    let pingadeira = document.querySelector('#pingadeira')

    pisos.style.display = 'none'
    revestimentos.style.display = 'none'
    cobogos.style.display = 'none'
    blocos.style.display = 'none'
    meiofio.style.display = 'block'
    pingadeira.style.display = 'none'
}

function pingadeira(){
    let pisos = document.querySelector('#pisos')
    let revestimentos = document.querySelector('#revestimentos')
    let cobogos = document.querySelector('#cobogos')
    let blocos = document.querySelector('#blocos')
    let meiofio = document.querySelector('#meiofio')
    let pingadeira = document.querySelector('#pingadeira')

    pisos.style.display = 'none'
    revestimentos.style.display = 'none'
    cobogos.style.display = 'none'
    blocos.style.display = 'none'
    meiofio.style.display = 'none'
    pingadeira.style.display = 'block'
}
